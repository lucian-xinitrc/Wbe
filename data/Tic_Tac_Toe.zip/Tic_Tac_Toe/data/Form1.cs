﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_Tac_Toe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int turn = 1;
        int c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0, c6 = 0, c7 = 0, c8 = 0, c9 = 0;
        int player1 = 0, player2 = 0;
        private void checkwin()
        {
            label1.Text = Convert.ToString(player1);
            label2.Text = Convert.ToString(player2);
        }
        private void reset()
        {
            c1 = 0;
            c2 = 0;
            c3 = 0;
            c4 = 0;
            c5 = 0;
            c6 = 0;
            c7 = 0;
            c8 = 0;
            c9 = 0;
            turn = 1;
            button1.Text = "";
            button2.Text = "";
            button3.Text = "";
            button4.Text = "";
            button5.Text = "";
            button6.Text = "";
            button7.Text = "";
            button8.Text = "";
            button9.Text = "";
        }
        private void Button8_Click(object sender, EventArgs e)
        {
            if (c8 == 0)
            {
                if (turn % 2 != 0)
                {
                    button8.Text = "X";
                    c8++;
                }
                else
                {
                    button8.Text = "O";
                    c8++;
                }
                turn++;
            }
            win();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Button10_Click(object sender, EventArgs e)
        {
           
        }

        private void Button11_Click(object sender, EventArgs e)
        {
            reset();
            player1 = 0;
            player2 = 0;
            label1.Text = "0";
            label2.Text = "0";
        }

        private void Button12_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void Button9_Click(object sender, EventArgs e)
        {
            if (c9 == 0)
            {
                if (turn % 2 != 0)
                {
                    button9.Text = "X";
                    c9++;
                }
                else
                {
                    button9.Text = "O";
                    c9++;
                }
                turn++;
            }
            win();
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            if (c7 == 0)
            {
                if (turn % 2 != 0)
                {
                    button7.Text = "X";
                    c7++;
                }
                else
                {
                    button7.Text = "O";
                    c7++;
                }
                turn++;
            }
            win();
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            if (c6 == 0)
            {
                if (turn % 2 != 0)
                {
                    button6.Text = "X";
                    c6++;
                }
                else
                {
                    button6.Text = "O";
                    c6++;
                }
                turn++;
            }
            win();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            if (c5 == 0)
            {
                if (turn % 2 != 0)
                {
                    button5.Text = "X";
                    c5++;
                }
                else
                {
                    button5.Text = "O";
                    c5++;
                }
                turn++;
            }
            win();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            if (c4 == 0)
            {
                if (turn % 2 != 0)
                {
                    button4.Text = "X";
                    c4++;
                }
                else
                {
                    button4.Text = "O";
                    c4++;
                }
                turn++;
            }
            win();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            if (c3 == 0)
            {
                if (turn % 2 != 0)
                {
                    button3.Text = "X";
                    c3++;
                }
                else
                {
                    button3.Text = "O";
                    c3++;
                }
                turn++;
            }
            win();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (c2 == 0)
            {
                if (turn % 2 != 0)
                {
                    button2.Text = "X";
                    c2++;
                }
                else
                {
                    button2.Text = "O";
                    c2++;
                }
                turn++;
            }
            win();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if(c1 == 0)
            {
                if(turn % 2 != 0)
                {
                    button1.Text = "X";
                    
                    c1++;
                }
                else
                {
                    button1.Text = "O";
                    c1++;
                }
                turn++;
            }
            win();
        }
        private void win()
        {
            if(button1.Text != "" && button2.Text != "" && button3.Text != "")
            {
                if(button1.Text == button2.Text && button2.Text == button3.Text)
                {
                    if(button1.Text == "X")
                    {
                        MessageBox.Show("A castigat X");
                        player1++;reset(); checkwin();
                }
                    else
                    {
                        MessageBox.Show("A castigat O");
                        player2++; reset(); checkwin();
                }
                }
            }
            if (button4.Text != "" && button5.Text != "" && button6.Text != "")
            {
                if (button4.Text == button5.Text && button5.Text == button6.Text)
                {
                    if (button4.Text == "X")
                    {
                        MessageBox.Show("A castigat X");
                        player1++; reset(); checkwin();
                }
                    else
                    {
                        MessageBox.Show("A castigat O");
                        player2++; reset(); checkwin();
                }
                }
            }
            if (button7.Text != "" && button8.Text != "" && button9.Text != "")
            {
                if (button7.Text == button8.Text && button8.Text == button9.Text)
                {
                    if (button7.Text == "X")
                    {
                        MessageBox.Show("A castigat X");
                        player1++; reset(); checkwin();
                }
                    else
                    {
                        MessageBox.Show("A castigat O");
                        player2++; reset(); checkwin();
                }
                }
            }
            if (button1.Text != "" && button4.Text != "" && button7.Text != "")
            {
                if (button1.Text == button4.Text && button4.Text == button7.Text)
                {
                    if (button1.Text == "X")
                    {
                        MessageBox.Show("A castigat X");
                        player1++; reset(); checkwin();
                }
                    else
                    {
                        MessageBox.Show("A castigat O");
                        player2++; reset(); checkwin();
                }
                }
            }
            if (button2.Text != "" && button5.Text != "" && button8.Text != "")
            {
                if (button5.Text == button2.Text && button2.Text == button8.Text)
                {
                    if (button2.Text == "X")
                    {
                        MessageBox.Show("A castigat X");
                        player1++; reset(); checkwin();
                }
                    else
                    {
                        MessageBox.Show("A castigat O");
                        player2++; reset(); checkwin();
                }
                }
            }
            if (button4.Text != "" && button6.Text != "" && button9.Text != "")
            {
                if (button4.Text == button6.Text && button6.Text == button9.Text)
                {
                    if (button4.Text == "X")
                    {
                        MessageBox.Show("A castigat X");
                        player1++; reset(); checkwin();
                }
                    else
                    {
                        MessageBox.Show("A castigat O");
                        player2++; reset(); checkwin();
                }
                }
            }
            if (button1.Text != "" && button5.Text != "" && button9.Text != "")
            {
                if (button1.Text == button5.Text && button5.Text == button9.Text)
                {
                    if (button1.Text == "X")
                    {
                        MessageBox.Show("A castigat X");
                        player1++; reset(); checkwin();
                }
                    else
                    {
                        MessageBox.Show("A castigat O");
                        player2++; reset(); checkwin();
                }
                }
            }
            if (button3.Text != "" && button5.Text != "" && button7.Text != "")
            {
                if (button3.Text == button5.Text && button5.Text == button7.Text)
                {
                    if (button3.Text == "X")
                    {
                        MessageBox.Show("A castigat X");
                        player1++; reset(); checkwin();
                }
                    else
                    {
                        MessageBox.Show("A castigat O");
                        player2++; reset(); checkwin();
                }
                }
            }
        }
    }
}
